<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Experience
 *
 * @ORM\Table(name="experience")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\ExperienceRepository")
 */
class Experience
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_debut", type="datetime", unique=true)
     */
    private $dateDebut;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_fin", type="datetime")
     */
    private $dateFin;

    /**
     * @var string
     *
     * @ORM\Column(name="exp_name", type="string", length=255)
     */
    private $expName;

    /**
     * @var string
     *
     * @ORM\Column(name="exp_desc", type="text")
     */
    private $expDesc;

    /**
     * @var string
     *
     * @ORM\Column(name="exp_factory", type="string", length=255)
     */
    private $expFactory;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dateDebut
     *
     * @param \DateTime $dateDebut
     *
     * @return Experience
     */
    public function setDateDebut($dateDebut)
    {
        $this->dateDebut = $dateDebut;

        return $this;
    }

    /**
     * Get dateDebut
     *
     * @return \DateTime
     */
    public function getDateDebut()
    {
        return $this->dateDebut;
    }

    /**
     * Set dateFin
     *
     * @param \DateTime $dateFin
     *
     * @return Experience
     */
    public function setDateFin($dateFin)
    {
        $this->dateFin = $dateFin;

        return $this;
    }

    /**
     * Get dateFin
     *
     * @return \DateTime
     */
    public function getDateFin()
    {
        return $this->dateFin;
    }
    

    /**
     * Set expName
     *
     * @param string $expName
     *
     * @return Experience
     */
    public function setExpName($expName)
    {
        $this->expName = $expName;

        return $this;
    }

    /**
     * Get expName
     *
     * @return string
     */
    public function getExpName()
    {
        return $this->expName;
    }

    /**
     * Set expDesc
     *
     * @param string $expDesc
     *
     * @return Experience
     */
    public function setExpDesc($expDesc)
    {
        $this->expDesc = $expDesc;

        return $this;
    }

    /**
     * Get expDesc
     *
     * @return string
     */
    public function getExpDesc()
    {
        return $this->expDesc;
    }

    /**
     * Set expFactory
     *
     * @param string $expFactory
     *
     * @return Experience
     */
    public function setExpFactory($expFactory)
    {
        $this->expFactory = $expFactory;

        return $this;
    }

    /**
     * Get expFactory
     *
     * @return string
     */
    public function getExpFactory()
    {
        return $this->expFactory;
    }
}

