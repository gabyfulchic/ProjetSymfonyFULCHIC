<?php

/* AppBundle::layout.html.twig */
class __TwigTemplate_d6d0acc3182c632ccb2e72957cf83b654ef0437344eeafb0d5857ff7f6337599 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>
        ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 6
        echo "    </title>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css\" integrity=\"sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb\" crossorigin=\"anonymous\">
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">
        <div class=\"container-fluid\">
            <a class=\"navbar-brand\" href=\"#\"><img src=\"\\gabycv\\web\\images\\monlog.png\" style=\"width: 100px; height: 100px;\" /> </a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNavAltMarkup\" aria-controls=\"navbarNavAltMarkup\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
            <ul class=\"nav navbar-nav\">
                <li><a class=\"nav-item nav-link active\" href=\"#\">Présentation </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Expériences </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Compétences</a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Centre d'intérêts</a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Me Contacter</a></li>
            </ul>
            <ul class=\"nav navbar-nav navbar-right\">
                <li><a class=\"nav-item nav-link\" href=\"#\">Se Connecter</a></li>
            </ul>
        </div>
    </nav>
</head>
<body>

";
        // line 29
        $this->displayBlock('javascript', $context, $blocks);
        // line 34
        echo "</body>

";
    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
    }

    // line 29
    public function block_javascript($context, array $blocks = array())
    {
        // line 30
        echo "    <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js\" integrity=\"sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh\" crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js\" integrity=\"sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ\" crossorigin=\"anonymous\"></script>
";
    }

    public function getTemplateName()
    {
        return "AppBundle::layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  70 => 30,  67 => 29,  62 => 5,  56 => 34,  54 => 29,  29 => 6,  27 => 5,  21 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle::layout.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle/Resources/views/layout.html.twig");
    }
}
