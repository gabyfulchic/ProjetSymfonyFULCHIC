<?php

/* @App/experiences/show_experiences.html.twig */
class __TwigTemplate_fc5d7bfe2d7979be4e1ef0c5c4eb7825be9312963449fac417cc0efe123a87a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle:defaults:layout.html.twig", "@App/experiences/show_experiences.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle:defaults:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f287211046deab68b424fb87281c14b9291a8700349c6678bffd629aa4f753e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f287211046deab68b424fb87281c14b9291a8700349c6678bffd629aa4f753e9->enter($__internal_f287211046deab68b424fb87281c14b9291a8700349c6678bffd629aa4f753e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/experiences/show_experiences.html.twig"));

        $__internal_4da65d3f62d85ff8a619b7326faa4d51bdc5a769151310641b469fa0d1dbdffb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4da65d3f62d85ff8a619b7326faa4d51bdc5a769151310641b469fa0d1dbdffb->enter($__internal_4da65d3f62d85ff8a619b7326faa4d51bdc5a769151310641b469fa0d1dbdffb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/experiences/show_experiences.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f287211046deab68b424fb87281c14b9291a8700349c6678bffd629aa4f753e9->leave($__internal_f287211046deab68b424fb87281c14b9291a8700349c6678bffd629aa4f753e9_prof);

        
        $__internal_4da65d3f62d85ff8a619b7326faa4d51bdc5a769151310641b469fa0d1dbdffb->leave($__internal_4da65d3f62d85ff8a619b7326faa4d51bdc5a769151310641b469fa0d1dbdffb_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0786b7cec1bf721e2bbd0cb5462f7ec70f193788b500c0d5f3705d203e08fa14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0786b7cec1bf721e2bbd0cb5462f7ec70f193788b500c0d5f3705d203e08fa14->enter($__internal_0786b7cec1bf721e2bbd0cb5462f7ec70f193788b500c0d5f3705d203e08fa14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_afb9a18e328074d29bfaabf4c3a58d48ccab4437cd7c2e4d0539dd1b0fe14758 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_afb9a18e328074d29bfaabf4c3a58d48ccab4437cd7c2e4d0539dd1b0fe14758->enter($__internal_afb9a18e328074d29bfaabf4c3a58d48ccab4437cd7c2e4d0539dd1b0fe14758_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <table class=\"table\">
        <thead class=\"thead-light\">
            <tr>
                <th scope=\"col\"> # </th>
                <th scope=\"col\"> Date de Début </th>
                <th scope=\"col\"> Date de Fin </th>
                <th scope=\"col\"> Entreprise  </th>
                <th scope=\"col\"> Description de l'expérience </th>
            </tr>
        </thead>
        <tbody>
    ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["e"]) ? $context["e"] : $this->getContext($context, "e")));
        foreach ($context['_seq'] as $context["_key"] => $context["experience"]) {
            // line 17
            echo "            <tr>
                <th scope=\"row\">";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["experience"], "id", array()), "html", null, true);
            echo "</th>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["experience"], "dateDebut", array()), "d/m/Y"), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["experience"], "dateFin", array()), "d/m/Y"), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["experience"], "expFactory", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["experience"], "expDesc", array()), "html", null, true);
            echo "</td>
            </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['experience'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "        </tbody>

";
        
        $__internal_afb9a18e328074d29bfaabf4c3a58d48ccab4437cd7c2e4d0539dd1b0fe14758->leave($__internal_afb9a18e328074d29bfaabf4c3a58d48ccab4437cd7c2e4d0539dd1b0fe14758_prof);

        
        $__internal_0786b7cec1bf721e2bbd0cb5462f7ec70f193788b500c0d5f3705d203e08fa14->leave($__internal_0786b7cec1bf721e2bbd0cb5462f7ec70f193788b500c0d5f3705d203e08fa14_prof);

    }

    public function getTemplateName()
    {
        return "@App/experiences/show_experiences.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 25,  86 => 22,  82 => 21,  78 => 20,  74 => 19,  70 => 18,  67 => 17,  63 => 16,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AppBundle:defaults:layout.html.twig' %}

{% block body %}

    <table class=\"table\">
        <thead class=\"thead-light\">
            <tr>
                <th scope=\"col\"> # </th>
                <th scope=\"col\"> Date de Début </th>
                <th scope=\"col\"> Date de Fin </th>
                <th scope=\"col\"> Entreprise  </th>
                <th scope=\"col\"> Description de l'expérience </th>
            </tr>
        </thead>
        <tbody>
    {% for experience in e %}
            <tr>
                <th scope=\"row\">{{ experience.id }}</th>
                <td>{{ experience.dateDebut|date(\"d/m/Y\") }}</td>
                <td>{{ experience.dateFin|date(\"d/m/Y\") }}</td>
                <td>{{ experience.expFactory }}</td>
                <td>{{ experience.expDesc }}</td>
            </tr>
    {% endfor %}
        </tbody>

{% endblock %}", "@App/experiences/show_experiences.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle\\Resources\\views\\experiences\\show_experiences.html.twig");
    }
}
