<?php

/* @App/competences/form_competence.html.twig */
class __TwigTemplate_9f1d778d72ad21c3604fcd8abfe4f73af3c2ffc5408d1abe90b32e0e87e6e41c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle:defaults:layout.html.twig", "@App/competences/form_competence.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle:defaults:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_85bfd11c3327d5c16bf540d023def02e7a2779a2bab4f888dce93aa8db9a12e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85bfd11c3327d5c16bf540d023def02e7a2779a2bab4f888dce93aa8db9a12e6->enter($__internal_85bfd11c3327d5c16bf540d023def02e7a2779a2bab4f888dce93aa8db9a12e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/competences/form_competence.html.twig"));

        $__internal_01784a34f58f6bcdd0b44446cd8ad5dcd4ca2b25a9153f125503cd1955a7a904 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01784a34f58f6bcdd0b44446cd8ad5dcd4ca2b25a9153f125503cd1955a7a904->enter($__internal_01784a34f58f6bcdd0b44446cd8ad5dcd4ca2b25a9153f125503cd1955a7a904_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/competences/form_competence.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_85bfd11c3327d5c16bf540d023def02e7a2779a2bab4f888dce93aa8db9a12e6->leave($__internal_85bfd11c3327d5c16bf540d023def02e7a2779a2bab4f888dce93aa8db9a12e6_prof);

        
        $__internal_01784a34f58f6bcdd0b44446cd8ad5dcd4ca2b25a9153f125503cd1955a7a904->leave($__internal_01784a34f58f6bcdd0b44446cd8ad5dcd4ca2b25a9153f125503cd1955a7a904_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3c5e6fe5c6bbb7b52f6e3fc503c08ba3dd323c974995abb46d2c87cf71103be4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c5e6fe5c6bbb7b52f6e3fc503c08ba3dd323c974995abb46d2c87cf71103be4->enter($__internal_3c5e6fe5c6bbb7b52f6e3fc503c08ba3dd323c974995abb46d2c87cf71103be4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c586ff416d9d15e84cf909ea4ce39db2c5a42c62535339312ddd62f5c7119692 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c586ff416d9d15e84cf909ea4ce39db2c5a42c62535339312ddd62f5c7119692->enter($__internal_c586ff416d9d15e84cf909ea4ce39db2c5a42c62535339312ddd62f5c7119692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <form>
        <div class=\"form-group\">
            <label for=\"exampleInputEmail1\">Nom de la compétence</label>
            <input type=\"email\" class=\"form-control\" id=\"exampleInputEmail1\" aria-describedby=\"emailHelp\" placeholder=\"Enter email\">
        </div>
        <div class=\"form-group\">
            <label for=\"exampleInputPassword1\">Niveau de la compétence sur 10</label>
            <input type=\"password\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Password\">
        </div>
        <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
    </form>
";
        
        $__internal_c586ff416d9d15e84cf909ea4ce39db2c5a42c62535339312ddd62f5c7119692->leave($__internal_c586ff416d9d15e84cf909ea4ce39db2c5a42c62535339312ddd62f5c7119692_prof);

        
        $__internal_3c5e6fe5c6bbb7b52f6e3fc503c08ba3dd323c974995abb46d2c87cf71103be4->leave($__internal_3c5e6fe5c6bbb7b52f6e3fc503c08ba3dd323c974995abb46d2c87cf71103be4_prof);

    }

    public function getTemplateName()
    {
        return "@App/competences/form_competence.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AppBundle:defaults:layout.html.twig' %}

{% block body %}
    <form>
        <div class=\"form-group\">
            <label for=\"exampleInputEmail1\">Nom de la compétence</label>
            <input type=\"email\" class=\"form-control\" id=\"exampleInputEmail1\" aria-describedby=\"emailHelp\" placeholder=\"Enter email\">
        </div>
        <div class=\"form-group\">
            <label for=\"exampleInputPassword1\">Niveau de la compétence sur 10</label>
            <input type=\"password\" class=\"form-control\" id=\"exampleInputPassword1\" placeholder=\"Password\">
        </div>
        <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
    </form>
{% endblock %}", "@App/competences/form_competence.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle\\Resources\\views\\competences\\form_competence.html.twig");
    }
}
