<?php

/* AppBundle:defaults:index.html.twig */
class __TwigTemplate_e3eca43ccb254b9952755df59a399101fc1404d2878c12f2e0b2693130ace284 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle:defaults:layout.html.twig", "AppBundle:defaults:index.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle:defaults:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2e289a86f31801824d0e054abad0cb4c01e794142dbfe3a6c7cefa235de0bdd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2e289a86f31801824d0e054abad0cb4c01e794142dbfe3a6c7cefa235de0bdd->enter($__internal_b2e289a86f31801824d0e054abad0cb4c01e794142dbfe3a6c7cefa235de0bdd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:defaults:index.html.twig"));

        $__internal_3e4920ef7893eaf854de1a18b2ab0c0b05733a55b5ecaeaee3676cb9f36485ac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e4920ef7893eaf854de1a18b2ab0c0b05733a55b5ecaeaee3676cb9f36485ac->enter($__internal_3e4920ef7893eaf854de1a18b2ab0c0b05733a55b5ecaeaee3676cb9f36485ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:defaults:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b2e289a86f31801824d0e054abad0cb4c01e794142dbfe3a6c7cefa235de0bdd->leave($__internal_b2e289a86f31801824d0e054abad0cb4c01e794142dbfe3a6c7cefa235de0bdd_prof);

        
        $__internal_3e4920ef7893eaf854de1a18b2ab0c0b05733a55b5ecaeaee3676cb9f36485ac->leave($__internal_3e4920ef7893eaf854de1a18b2ab0c0b05733a55b5ecaeaee3676cb9f36485ac_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:defaults:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AppBundle:defaults:layout.html.twig' %}

", "AppBundle:defaults:index.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle/Resources/views/defaults/index.html.twig");
    }
}
