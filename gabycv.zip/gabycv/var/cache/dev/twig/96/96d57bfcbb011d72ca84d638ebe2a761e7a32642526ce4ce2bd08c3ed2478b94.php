<?php

/* @App/competences/show_competences.html.twig */
class __TwigTemplate_63f83928cbb2ee9124317d46bc5ec42f42c46bc7d3ba8df0711adf86a00bf4d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle:defaults:layout.html.twig", "@App/competences/show_competences.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle:defaults:layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f74e7fa861e7dddbe23f1e39949d5df6f33340ac585075bee1790dfd4b25fec3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f74e7fa861e7dddbe23f1e39949d5df6f33340ac585075bee1790dfd4b25fec3->enter($__internal_f74e7fa861e7dddbe23f1e39949d5df6f33340ac585075bee1790dfd4b25fec3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/competences/show_competences.html.twig"));

        $__internal_edc8bc19d53e3df8268e087ef8974e18629c267a6ce771033bb10b1e594cb0cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_edc8bc19d53e3df8268e087ef8974e18629c267a6ce771033bb10b1e594cb0cf->enter($__internal_edc8bc19d53e3df8268e087ef8974e18629c267a6ce771033bb10b1e594cb0cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/competences/show_competences.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f74e7fa861e7dddbe23f1e39949d5df6f33340ac585075bee1790dfd4b25fec3->leave($__internal_f74e7fa861e7dddbe23f1e39949d5df6f33340ac585075bee1790dfd4b25fec3_prof);

        
        $__internal_edc8bc19d53e3df8268e087ef8974e18629c267a6ce771033bb10b1e594cb0cf->leave($__internal_edc8bc19d53e3df8268e087ef8974e18629c267a6ce771033bb10b1e594cb0cf_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_484ffc08259873130be40761bb02c9822762854b166cb664e9e9bb7ac3e59de5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_484ffc08259873130be40761bb02c9822762854b166cb664e9e9bb7ac3e59de5->enter($__internal_484ffc08259873130be40761bb02c9822762854b166cb664e9e9bb7ac3e59de5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_744e13dc0f164ed7108ce4f50c4939750ac056f2e7589eaadff689672d99f19a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_744e13dc0f164ed7108ce4f50c4939750ac056f2e7589eaadff689672d99f19a->enter($__internal_744e13dc0f164ed7108ce4f50c4939750ac056f2e7589eaadff689672d99f19a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <table class=\"table\">
    <thead class=\"thead-light\">
    <tr>
        <th scope=\"col\"> # </th>
        <th scope=\"col\"> Nom de la compétence </th>
        <th scope=\"col\"> Niveau de la compétence </th>
    </tr>
    </thead>
    <tbody>
    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")));
        foreach ($context['_seq'] as $context["_key"] => $context["competence"]) {
            // line 14
            echo "        <tr>
            <th scope=\"row\">";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["competence"], "id", array()), "html", null, true);
            echo "</th>
            <td>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["competence"], "compName", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["competence"], "compLevel", array()), "html", null, true);
            echo "</td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['competence'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "    </tbody>
    </table>
    <a href=\"";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("form");
        echo "\"><button type=\"button\" class=\"btn btn-primary btn-lg btn-block\">Add New</button></a>

";
        
        $__internal_744e13dc0f164ed7108ce4f50c4939750ac056f2e7589eaadff689672d99f19a->leave($__internal_744e13dc0f164ed7108ce4f50c4939750ac056f2e7589eaadff689672d99f19a_prof);

        
        $__internal_484ffc08259873130be40761bb02c9822762854b166cb664e9e9bb7ac3e59de5->leave($__internal_484ffc08259873130be40761bb02c9822762854b166cb664e9e9bb7ac3e59de5_prof);

    }

    public function getTemplateName()
    {
        return "@App/competences/show_competences.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 22,  84 => 20,  75 => 17,  71 => 16,  67 => 15,  64 => 14,  60 => 13,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AppBundle:defaults:layout.html.twig' %}

{% block body %}
    <table class=\"table\">
    <thead class=\"thead-light\">
    <tr>
        <th scope=\"col\"> # </th>
        <th scope=\"col\"> Nom de la compétence </th>
        <th scope=\"col\"> Niveau de la compétence </th>
    </tr>
    </thead>
    <tbody>
    {% for competence in c %}
        <tr>
            <th scope=\"row\">{{ competence.id }}</th>
            <td>{{ competence.compName }}</td>
            <td>{{ competence.compLevel }}</td>
        </tr>
    {% endfor %}
    </tbody>
    </table>
    <a href=\"{{ path('form') }}\"><button type=\"button\" class=\"btn btn-primary btn-lg btn-block\">Add New</button></a>

{% endblock %}", "@App/competences/show_competences.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle\\Resources\\views\\competences\\show_competences.html.twig");
    }
}
