<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_298b9d532c6f95ae216b7e059274db33509b27f2aacdee327036a4a77528d802 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6e26cb5c64da78e1502d390a7b31aed9baec7128ec35ae9a929da83a28e24eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6e26cb5c64da78e1502d390a7b31aed9baec7128ec35ae9a929da83a28e24eb->enter($__internal_f6e26cb5c64da78e1502d390a7b31aed9baec7128ec35ae9a929da83a28e24eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_f97307ade6ce6922cadbbd15e3b93a144e9425af376c70048930024668625927 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f97307ade6ce6922cadbbd15e3b93a144e9425af376c70048930024668625927->enter($__internal_f97307ade6ce6922cadbbd15e3b93a144e9425af376c70048930024668625927_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f6e26cb5c64da78e1502d390a7b31aed9baec7128ec35ae9a929da83a28e24eb->leave($__internal_f6e26cb5c64da78e1502d390a7b31aed9baec7128ec35ae9a929da83a28e24eb_prof);

        
        $__internal_f97307ade6ce6922cadbbd15e3b93a144e9425af376c70048930024668625927->leave($__internal_f97307ade6ce6922cadbbd15e3b93a144e9425af376c70048930024668625927_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_3ce6586f46c09423f68772a469654ea7fbdf05b702e61becd9b9ace4f617dce4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ce6586f46c09423f68772a469654ea7fbdf05b702e61becd9b9ace4f617dce4->enter($__internal_3ce6586f46c09423f68772a469654ea7fbdf05b702e61becd9b9ace4f617dce4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_d6f5eff7d2246d44f1d84ec68948547090a0a71a742d3b4b57ceb15224548349 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6f5eff7d2246d44f1d84ec68948547090a0a71a742d3b4b57ceb15224548349->enter($__internal_d6f5eff7d2246d44f1d84ec68948547090a0a71a742d3b4b57ceb15224548349_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_d6f5eff7d2246d44f1d84ec68948547090a0a71a742d3b4b57ceb15224548349->leave($__internal_d6f5eff7d2246d44f1d84ec68948547090a0a71a742d3b4b57ceb15224548349_prof);

        
        $__internal_3ce6586f46c09423f68772a469654ea7fbdf05b702e61becd9b9ace4f617dce4->leave($__internal_3ce6586f46c09423f68772a469654ea7fbdf05b702e61becd9b9ace4f617dce4_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_280a1cab4202d496d8e5c18b3251348625304669b55e57c637fd112065d0e3d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_280a1cab4202d496d8e5c18b3251348625304669b55e57c637fd112065d0e3d1->enter($__internal_280a1cab4202d496d8e5c18b3251348625304669b55e57c637fd112065d0e3d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_aef67363309a5293a254daf22df46a32a9bc85e2cf35843901cfcda7a9a53a92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aef67363309a5293a254daf22df46a32a9bc85e2cf35843901cfcda7a9a53a92->enter($__internal_aef67363309a5293a254daf22df46a32a9bc85e2cf35843901cfcda7a9a53a92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_aef67363309a5293a254daf22df46a32a9bc85e2cf35843901cfcda7a9a53a92->leave($__internal_aef67363309a5293a254daf22df46a32a9bc85e2cf35843901cfcda7a9a53a92_prof);

        
        $__internal_280a1cab4202d496d8e5c18b3251348625304669b55e57c637fd112065d0e3d1->leave($__internal_280a1cab4202d496d8e5c18b3251348625304669b55e57c637fd112065d0e3d1_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ce8e08df22d1f4221b4947287e2219bf23b4d4091e81d9913a25a730bf68a7c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce8e08df22d1f4221b4947287e2219bf23b4d4091e81d9913a25a730bf68a7c4->enter($__internal_ce8e08df22d1f4221b4947287e2219bf23b4d4091e81d9913a25a730bf68a7c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9f5c99d4f521d7d9fd641b2a554c877d18bfb502ac494527009ce410cdd369da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f5c99d4f521d7d9fd641b2a554c877d18bfb502ac494527009ce410cdd369da->enter($__internal_9f5c99d4f521d7d9fd641b2a554c877d18bfb502ac494527009ce410cdd369da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_9f5c99d4f521d7d9fd641b2a554c877d18bfb502ac494527009ce410cdd369da->leave($__internal_9f5c99d4f521d7d9fd641b2a554c877d18bfb502ac494527009ce410cdd369da_prof);

        
        $__internal_ce8e08df22d1f4221b4947287e2219bf23b4d4091e81d9913a25a730bf68a7c4->leave($__internal_ce8e08df22d1f4221b4947287e2219bf23b4d4091e81d9913a25a730bf68a7c4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp64\\www\\gabycv\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
