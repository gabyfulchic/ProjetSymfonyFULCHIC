<?php

/* AppBundle:defaults:layout.html.twig */
class __TwigTemplate_a5a6f3e50c9668eca62a390bc69d1e3051d1fcd85d28b249283806a86b1c1e94 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2cbfd847a06632ab9f98ddec41016e56729517ba90618fa37f6f5fc58a4142d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b2cbfd847a06632ab9f98ddec41016e56729517ba90618fa37f6f5fc58a4142d->enter($__internal_b2cbfd847a06632ab9f98ddec41016e56729517ba90618fa37f6f5fc58a4142d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:defaults:layout.html.twig"));

        $__internal_63558ef34c31b7cb7c488038fc3ba38b0586b4b172a64ce59b9653e1e84e20f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63558ef34c31b7cb7c488038fc3ba38b0586b4b172a64ce59b9653e1e84e20f9->enter($__internal_63558ef34c31b7cb7c488038fc3ba38b0586b4b172a64ce59b9653e1e84e20f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:defaults:layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>
        ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 6
        echo "    </title>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css\" integrity=\"sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb\" crossorigin=\"anonymous\">

</head>
<body>
    <header>
        <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">
            <div class=\"container-fluid\">
                <a class=\"navbar-brand\" href=\"#\"><img src=\"\\gabycv\\web\\images\\monlog.png\" style=\"width: 100px; height: 100px;\" /> </a>
                <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNavAltMarkup\" aria-controls=\"navbarNavAltMarkup\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>
                <ul class=\"nav navbar-nav\">
                    <li><a class=\"nav-item nav-link active\" href=\"/gabycv/web/app_dev.php/\">Présentation </a></li>
                    <li><a class=\"nav-item nav-link\" href=\"/gabycv/web/app_dev.php/experience\">Expériences </a></li>
                    <li><a class=\"nav-item nav-link\" href=\"/gabycv/web/app_dev.php/competence\">Compétences</a></li>
                    <li><a class=\"nav-item nav-link\" href=\"#\">Centre d'intérêts</a></li>
                    <li><a class=\"nav-item nav-link\" href=\"#\">Blog </a></li>
                    <li><a class=\"nav-item nav-link\" href=\"#\">Me Contacter</a></li>
                </ul>
                <ul class=\"nav navbar-nav navbar-right\">
                    <li><a class=\"nav-item nav-link\" href=\"#\">Se Connecter</a></li>
                </ul>
            </div>
        </nav>
    </header>

    ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 35
        echo "
    <footer style=\"background: #0088CC; bottom: 0px; left: 0px; position: fixed; width: 100%; height: 10%;\">
            <div class=\"txt&icon\" style=\"width: 30%; height: 50%\">
                <div class=\"contact\" style=\"margin-left: 12%\">
                    •  Veuillez me contacter ici  •
                </div>
                <div class=\"footer\"; >
                    <a class=\"nav-item nav-link\" href=\"https://www.facebook.com/gaby.fulchic\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\facebook.png\"/> </a>
                    <a class=\"nav-item nav-link\" href=\"https://www.linkedin.com/in/gaby-fulchic-857799139/\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\linkedin.png\"/></a>
                    <a class=\"nav-item nav-link\" href=\"#\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\blogging.png\"/></a>
                    <a class=\"nav-item nav-link\" href=\"https://github.com/gabyfulchic\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\github-logo.png\"/></a>
                    <a class=\"nav-item nav-link\" href=\"mailto:gaby.fulchic@ynov.com\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\email (1).png\"/></a>
                </div>
            </div>


    </footer>

    ";
        // line 53
        $this->displayBlock('javascript', $context, $blocks);
        // line 58
        echo "
</body>



";
        
        $__internal_b2cbfd847a06632ab9f98ddec41016e56729517ba90618fa37f6f5fc58a4142d->leave($__internal_b2cbfd847a06632ab9f98ddec41016e56729517ba90618fa37f6f5fc58a4142d_prof);

        
        $__internal_63558ef34c31b7cb7c488038fc3ba38b0586b4b172a64ce59b9653e1e84e20f9->leave($__internal_63558ef34c31b7cb7c488038fc3ba38b0586b4b172a64ce59b9653e1e84e20f9_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_5f2f998335f9347d57138b6cf95dd9acbe97ce0c5e806b93695e29e43d0f6249 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f2f998335f9347d57138b6cf95dd9acbe97ce0c5e806b93695e29e43d0f6249->enter($__internal_5f2f998335f9347d57138b6cf95dd9acbe97ce0c5e806b93695e29e43d0f6249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_426ef03fd97038957bbe4a939ccd37f8642660da83ff997064c123b00879e9ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_426ef03fd97038957bbe4a939ccd37f8642660da83ff997064c123b00879e9ee->enter($__internal_426ef03fd97038957bbe4a939ccd37f8642660da83ff997064c123b00879e9ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_426ef03fd97038957bbe4a939ccd37f8642660da83ff997064c123b00879e9ee->leave($__internal_426ef03fd97038957bbe4a939ccd37f8642660da83ff997064c123b00879e9ee_prof);

        
        $__internal_5f2f998335f9347d57138b6cf95dd9acbe97ce0c5e806b93695e29e43d0f6249->leave($__internal_5f2f998335f9347d57138b6cf95dd9acbe97ce0c5e806b93695e29e43d0f6249_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_b0e71d2505fff28a850069cdcc905ecc25164d63a84386247fa9212eeb6c393a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b0e71d2505fff28a850069cdcc905ecc25164d63a84386247fa9212eeb6c393a->enter($__internal_b0e71d2505fff28a850069cdcc905ecc25164d63a84386247fa9212eeb6c393a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2b1ebbc57e9c3ae2d4d0b8a1a7de9b3aefe0b86a30e7acf3fdc0d34246398792 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b1ebbc57e9c3ae2d4d0b8a1a7de9b3aefe0b86a30e7acf3fdc0d34246398792->enter($__internal_2b1ebbc57e9c3ae2d4d0b8a1a7de9b3aefe0b86a30e7acf3fdc0d34246398792_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 34
        echo "    ";
        
        $__internal_2b1ebbc57e9c3ae2d4d0b8a1a7de9b3aefe0b86a30e7acf3fdc0d34246398792->leave($__internal_2b1ebbc57e9c3ae2d4d0b8a1a7de9b3aefe0b86a30e7acf3fdc0d34246398792_prof);

        
        $__internal_b0e71d2505fff28a850069cdcc905ecc25164d63a84386247fa9212eeb6c393a->leave($__internal_b0e71d2505fff28a850069cdcc905ecc25164d63a84386247fa9212eeb6c393a_prof);

    }

    // line 53
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_c8fa9004dc2df48e40b19283269224716112278f06ceba8ca12aefd3f8c50a22 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c8fa9004dc2df48e40b19283269224716112278f06ceba8ca12aefd3f8c50a22->enter($__internal_c8fa9004dc2df48e40b19283269224716112278f06ceba8ca12aefd3f8c50a22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_4c7741be49183d28c2a089654e23078a9568c235a4a9dd56495668e9e22eac8f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c7741be49183d28c2a089654e23078a9568c235a4a9dd56495668e9e22eac8f->enter($__internal_4c7741be49183d28c2a089654e23078a9568c235a4a9dd56495668e9e22eac8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 54
        echo "        <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js\" integrity=\"sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh\" crossorigin=\"anonymous\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js\" integrity=\"sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ\" crossorigin=\"anonymous\"></script>
    ";
        
        $__internal_4c7741be49183d28c2a089654e23078a9568c235a4a9dd56495668e9e22eac8f->leave($__internal_4c7741be49183d28c2a089654e23078a9568c235a4a9dd56495668e9e22eac8f_prof);

        
        $__internal_c8fa9004dc2df48e40b19283269224716112278f06ceba8ca12aefd3f8c50a22->leave($__internal_c8fa9004dc2df48e40b19283269224716112278f06ceba8ca12aefd3f8c50a22_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:defaults:layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  149 => 54,  140 => 53,  130 => 34,  121 => 33,  104 => 5,  89 => 58,  87 => 53,  67 => 35,  65 => 33,  36 => 6,  34 => 5,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <title>
        {% block title %}{% endblock %}
    </title>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css\" integrity=\"sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb\" crossorigin=\"anonymous\">

</head>
<body>
    <header>
        <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">
            <div class=\"container-fluid\">
                <a class=\"navbar-brand\" href=\"#\"><img src=\"\\gabycv\\web\\images\\monlog.png\" style=\"width: 100px; height: 100px;\" /> </a>
                <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNavAltMarkup\" aria-controls=\"navbarNavAltMarkup\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>
                <ul class=\"nav navbar-nav\">
                    <li><a class=\"nav-item nav-link active\" href=\"/gabycv/web/app_dev.php/\">Présentation </a></li>
                    <li><a class=\"nav-item nav-link\" href=\"/gabycv/web/app_dev.php/experience\">Expériences </a></li>
                    <li><a class=\"nav-item nav-link\" href=\"/gabycv/web/app_dev.php/competence\">Compétences</a></li>
                    <li><a class=\"nav-item nav-link\" href=\"#\">Centre d'intérêts</a></li>
                    <li><a class=\"nav-item nav-link\" href=\"#\">Blog </a></li>
                    <li><a class=\"nav-item nav-link\" href=\"#\">Me Contacter</a></li>
                </ul>
                <ul class=\"nav navbar-nav navbar-right\">
                    <li><a class=\"nav-item nav-link\" href=\"#\">Se Connecter</a></li>
                </ul>
            </div>
        </nav>
    </header>

    {% block body %}
    {% endblock %}

    <footer style=\"background: #0088CC; bottom: 0px; left: 0px; position: fixed; width: 100%; height: 10%;\">
            <div class=\"txt&icon\" style=\"width: 30%; height: 50%\">
                <div class=\"contact\" style=\"margin-left: 12%\">
                    •  Veuillez me contacter ici  •
                </div>
                <div class=\"footer\"; >
                    <a class=\"nav-item nav-link\" href=\"https://www.facebook.com/gaby.fulchic\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\facebook.png\"/> </a>
                    <a class=\"nav-item nav-link\" href=\"https://www.linkedin.com/in/gaby-fulchic-857799139/\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\linkedin.png\"/></a>
                    <a class=\"nav-item nav-link\" href=\"#\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\blogging.png\"/></a>
                    <a class=\"nav-item nav-link\" href=\"https://github.com/gabyfulchic\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\github-logo.png\"/></a>
                    <a class=\"nav-item nav-link\" href=\"mailto:gaby.fulchic@ynov.com\" style=\"float: left;\"><img src=\"\\gabycv\\web\\images\\email (1).png\"/></a>
                </div>
            </div>


    </footer>

    {% block javascript %}
        <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js\" integrity=\"sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh\" crossorigin=\"anonymous\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js\" integrity=\"sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ\" crossorigin=\"anonymous\"></script>
    {% endblock %}

</body>



", "AppBundle:defaults:layout.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle/Resources/views/defaults/layout.html.twig");
    }
}
