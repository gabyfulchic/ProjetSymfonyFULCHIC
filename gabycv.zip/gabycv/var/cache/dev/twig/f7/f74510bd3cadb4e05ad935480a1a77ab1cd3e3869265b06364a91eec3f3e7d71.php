<?php

/* AppBundle::layout.html.twig */
class __TwigTemplate_21937125ff6c1198c9c5817c47096938f1660243b03eb8e3d82fa8dce44ce888 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'javascript' => array($this, 'block_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75412243db70bc2975fcde360be7fd7614c382ae5186df608a0e720c2ff23b1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_75412243db70bc2975fcde360be7fd7614c382ae5186df608a0e720c2ff23b1d->enter($__internal_75412243db70bc2975fcde360be7fd7614c382ae5186df608a0e720c2ff23b1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle::layout.html.twig"));

        $__internal_ff129c377bcbd1f1cfe590fde4c3a14135b15d88a9df70d19df59f35245f81f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff129c377bcbd1f1cfe590fde4c3a14135b15d88a9df70d19df59f35245f81f4->enter($__internal_ff129c377bcbd1f1cfe590fde4c3a14135b15d88a9df70d19df59f35245f81f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>
        ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 6
        echo "    </title>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css\" integrity=\"sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb\" crossorigin=\"anonymous\">
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">
        <div class=\"container-fluid\">
            <a class=\"navbar-brand\" href=\"#\"><img src=\"\\gabycv\\web\\images\\monlog.png\" style=\"width: 100px; height: 100px;\" /> </a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNavAltMarkup\" aria-controls=\"navbarNavAltMarkup\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
            <ul class=\"nav navbar-nav\">
                <li><a class=\"nav-item nav-link active\" href=\"#\">Présentation </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Expériences </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Compétences</a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Centre d'intérêts</a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Blog </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Me Contacter</a></li>
            </ul>
            <ul class=\"nav navbar-nav navbar-right\">
                <li><a class=\"nav-item nav-link\" href=\"#\">Se Connecter</a></li>
            </ul>
        </div>
    </nav>
</head>
<body>

";
        // line 30
        $this->displayBlock('javascript', $context, $blocks);
        // line 35
        echo "</body>

";
        
        $__internal_75412243db70bc2975fcde360be7fd7614c382ae5186df608a0e720c2ff23b1d->leave($__internal_75412243db70bc2975fcde360be7fd7614c382ae5186df608a0e720c2ff23b1d_prof);

        
        $__internal_ff129c377bcbd1f1cfe590fde4c3a14135b15d88a9df70d19df59f35245f81f4->leave($__internal_ff129c377bcbd1f1cfe590fde4c3a14135b15d88a9df70d19df59f35245f81f4_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_03954b902db02539b6221cc720020d244e5f5145b152a76223cd5c40741c78ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03954b902db02539b6221cc720020d244e5f5145b152a76223cd5c40741c78ba->enter($__internal_03954b902db02539b6221cc720020d244e5f5145b152a76223cd5c40741c78ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_34dcf2588fe80141fd900e527cd8ab0d6f9ce222dd123a53bd09fb090c654c5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_34dcf2588fe80141fd900e527cd8ab0d6f9ce222dd123a53bd09fb090c654c5b->enter($__internal_34dcf2588fe80141fd900e527cd8ab0d6f9ce222dd123a53bd09fb090c654c5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_34dcf2588fe80141fd900e527cd8ab0d6f9ce222dd123a53bd09fb090c654c5b->leave($__internal_34dcf2588fe80141fd900e527cd8ab0d6f9ce222dd123a53bd09fb090c654c5b_prof);

        
        $__internal_03954b902db02539b6221cc720020d244e5f5145b152a76223cd5c40741c78ba->leave($__internal_03954b902db02539b6221cc720020d244e5f5145b152a76223cd5c40741c78ba_prof);

    }

    // line 30
    public function block_javascript($context, array $blocks = array())
    {
        $__internal_0a9a80a504c9ffb963b86f159fc913041829f1f0f002776764ef6eca4326bf75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a9a80a504c9ffb963b86f159fc913041829f1f0f002776764ef6eca4326bf75->enter($__internal_0a9a80a504c9ffb963b86f159fc913041829f1f0f002776764ef6eca4326bf75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_e94d496ea805168a9fb43062d141b47b665e1b6a552f026d805039470a51951b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e94d496ea805168a9fb43062d141b47b665e1b6a552f026d805039470a51951b->enter($__internal_e94d496ea805168a9fb43062d141b47b665e1b6a552f026d805039470a51951b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascript"));

        // line 31
        echo "    <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js\" integrity=\"sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh\" crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js\" integrity=\"sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ\" crossorigin=\"anonymous\"></script>
";
        
        $__internal_e94d496ea805168a9fb43062d141b47b665e1b6a552f026d805039470a51951b->leave($__internal_e94d496ea805168a9fb43062d141b47b665e1b6a552f026d805039470a51951b_prof);

        
        $__internal_0a9a80a504c9ffb963b86f159fc913041829f1f0f002776764ef6eca4326bf75->leave($__internal_0a9a80a504c9ffb963b86f159fc913041829f1f0f002776764ef6eca4326bf75_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle::layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  101 => 31,  92 => 30,  75 => 5,  63 => 35,  61 => 30,  35 => 6,  33 => 5,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <title>
        {% block title %}{% endblock %}
    </title>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css\" integrity=\"sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb\" crossorigin=\"anonymous\">
    <nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">
        <div class=\"container-fluid\">
            <a class=\"navbar-brand\" href=\"#\"><img src=\"\\gabycv\\web\\images\\monlog.png\" style=\"width: 100px; height: 100px;\" /> </a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarNavAltMarkup\" aria-controls=\"navbarNavAltMarkup\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>
            <ul class=\"nav navbar-nav\">
                <li><a class=\"nav-item nav-link active\" href=\"#\">Présentation </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Expériences </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Compétences</a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Centre d'intérêts</a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Blog </a></li>
                <li><a class=\"nav-item nav-link\" href=\"#\">Me Contacter</a></li>
            </ul>
            <ul class=\"nav navbar-nav navbar-right\">
                <li><a class=\"nav-item nav-link\" href=\"#\">Se Connecter</a></li>
            </ul>
        </div>
    </nav>
</head>
<body>

{% block javascript %}
    <script src=\"https://code.jquery.com/jquery-3.2.1.slim.min.js\" integrity=\"sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN\" crossorigin=\"anonymous\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js\" integrity=\"sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh\" crossorigin=\"anonymous\"></script>
    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js\" integrity=\"sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ\" crossorigin=\"anonymous\"></script>
{% endblock %}
</body>

", "AppBundle::layout.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle/Resources/views/layout.html.twig");
    }
}
