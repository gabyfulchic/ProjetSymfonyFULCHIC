<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_5d54ece49f3eaea3b8641a621aa5ea65eab7f2456c91cd9fb7e51d715f7116e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_979a1ddfb8136c5623f9ccd1ada55683c21455d153237b067c86ddb38744b174 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_979a1ddfb8136c5623f9ccd1ada55683c21455d153237b067c86ddb38744b174->enter($__internal_979a1ddfb8136c5623f9ccd1ada55683c21455d153237b067c86ddb38744b174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_e49797a3a8e683ae66b041cde34089e5099d54abb0a4eb790f2dee1601309a9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e49797a3a8e683ae66b041cde34089e5099d54abb0a4eb790f2dee1601309a9e->enter($__internal_e49797a3a8e683ae66b041cde34089e5099d54abb0a4eb790f2dee1601309a9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_979a1ddfb8136c5623f9ccd1ada55683c21455d153237b067c86ddb38744b174->leave($__internal_979a1ddfb8136c5623f9ccd1ada55683c21455d153237b067c86ddb38744b174_prof);

        
        $__internal_e49797a3a8e683ae66b041cde34089e5099d54abb0a4eb790f2dee1601309a9e->leave($__internal_e49797a3a8e683ae66b041cde34089e5099d54abb0a4eb790f2dee1601309a9e_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_b24737fa5a664c3fc129e0fb91bd6441eb4a1a7b06df8b9754927308a0d1f0dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b24737fa5a664c3fc129e0fb91bd6441eb4a1a7b06df8b9754927308a0d1f0dc->enter($__internal_b24737fa5a664c3fc129e0fb91bd6441eb4a1a7b06df8b9754927308a0d1f0dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_849607734cc77a9dbb79ad347681638e63e395300f20704d3c1e727c92471f47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_849607734cc77a9dbb79ad347681638e63e395300f20704d3c1e727c92471f47->enter($__internal_849607734cc77a9dbb79ad347681638e63e395300f20704d3c1e727c92471f47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_849607734cc77a9dbb79ad347681638e63e395300f20704d3c1e727c92471f47->leave($__internal_849607734cc77a9dbb79ad347681638e63e395300f20704d3c1e727c92471f47_prof);

        
        $__internal_b24737fa5a664c3fc129e0fb91bd6441eb4a1a7b06df8b9754927308a0d1f0dc->leave($__internal_b24737fa5a664c3fc129e0fb91bd6441eb4a1a7b06df8b9754927308a0d1f0dc_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_44fad2041dfbb7666345cb61464d2b1b039fe6d6ed4f27c1682c7f9c79c3db98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44fad2041dfbb7666345cb61464d2b1b039fe6d6ed4f27c1682c7f9c79c3db98->enter($__internal_44fad2041dfbb7666345cb61464d2b1b039fe6d6ed4f27c1682c7f9c79c3db98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ea6aefe3ecb6e08a3f7108878541dd3e9cc944854499cf4dd5f40e7e8837efea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea6aefe3ecb6e08a3f7108878541dd3e9cc944854499cf4dd5f40e7e8837efea->enter($__internal_ea6aefe3ecb6e08a3f7108878541dd3e9cc944854499cf4dd5f40e7e8837efea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_ea6aefe3ecb6e08a3f7108878541dd3e9cc944854499cf4dd5f40e7e8837efea->leave($__internal_ea6aefe3ecb6e08a3f7108878541dd3e9cc944854499cf4dd5f40e7e8837efea_prof);

        
        $__internal_44fad2041dfbb7666345cb61464d2b1b039fe6d6ed4f27c1682c7f9c79c3db98->leave($__internal_44fad2041dfbb7666345cb61464d2b1b039fe6d6ed4f27c1682c7f9c79c3db98_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_25f7f95b26d1e61d9cca88b7f98828ff2f09744483b99f8680ec685eafacbac3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25f7f95b26d1e61d9cca88b7f98828ff2f09744483b99f8680ec685eafacbac3->enter($__internal_25f7f95b26d1e61d9cca88b7f98828ff2f09744483b99f8680ec685eafacbac3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_98fa3edeb11a15c8b1ce5f4e93fd654972900a45f14b44ec1c8a532ef7d132bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98fa3edeb11a15c8b1ce5f4e93fd654972900a45f14b44ec1c8a532ef7d132bd->enter($__internal_98fa3edeb11a15c8b1ce5f4e93fd654972900a45f14b44ec1c8a532ef7d132bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_98fa3edeb11a15c8b1ce5f4e93fd654972900a45f14b44ec1c8a532ef7d132bd->leave($__internal_98fa3edeb11a15c8b1ce5f4e93fd654972900a45f14b44ec1c8a532ef7d132bd_prof);

        
        $__internal_25f7f95b26d1e61d9cca88b7f98828ff2f09744483b99f8680ec685eafacbac3->leave($__internal_25f7f95b26d1e61d9cca88b7f98828ff2f09744483b99f8680ec685eafacbac3_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\wamp64\\www\\gabycv\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
