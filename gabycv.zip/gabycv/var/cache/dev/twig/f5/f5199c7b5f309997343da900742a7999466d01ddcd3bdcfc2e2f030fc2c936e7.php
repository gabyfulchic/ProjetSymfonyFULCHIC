<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_caa9bfc8cb31048b2c5c715d1e2e5c6693575be9077b7f817476c8280bad5802 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b099538c890d0498efb37b66672d985cb016993900447b00f824e3e0983466a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b099538c890d0498efb37b66672d985cb016993900447b00f824e3e0983466a7->enter($__internal_b099538c890d0498efb37b66672d985cb016993900447b00f824e3e0983466a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_31a8d44f380c1444df2a4e60f9392aafa148cdafa6d01a7218da2388d55574d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31a8d44f380c1444df2a4e60f9392aafa148cdafa6d01a7218da2388d55574d1->enter($__internal_31a8d44f380c1444df2a4e60f9392aafa148cdafa6d01a7218da2388d55574d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_b099538c890d0498efb37b66672d985cb016993900447b00f824e3e0983466a7->leave($__internal_b099538c890d0498efb37b66672d985cb016993900447b00f824e3e0983466a7_prof);

        
        $__internal_31a8d44f380c1444df2a4e60f9392aafa148cdafa6d01a7218da2388d55574d1->leave($__internal_31a8d44f380c1444df2a4e60f9392aafa148cdafa6d01a7218da2388d55574d1_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "C:\\wamp64\\www\\gabycv\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
