<?php

/* AppBundle::index.html.twig */
class __TwigTemplate_481d17732f81ce7306c6dd8c4dc627454e8d9972c63cf001e59bb9c317ad218a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle::index.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4177012defc9e4fed93a0a3d99bae49bf127cfddb5fed0cebeac6f1ee4b6ce39 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4177012defc9e4fed93a0a3d99bae49bf127cfddb5fed0cebeac6f1ee4b6ce39->enter($__internal_4177012defc9e4fed93a0a3d99bae49bf127cfddb5fed0cebeac6f1ee4b6ce39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle::index.html.twig"));

        $__internal_f540e1ba7c5ab7e9b812dd346559cb7f5025a4c870c747f94d0e0676836cabb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f540e1ba7c5ab7e9b812dd346559cb7f5025a4c870c747f94d0e0676836cabb7->enter($__internal_f540e1ba7c5ab7e9b812dd346559cb7f5025a4c870c747f94d0e0676836cabb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle::index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4177012defc9e4fed93a0a3d99bae49bf127cfddb5fed0cebeac6f1ee4b6ce39->leave($__internal_4177012defc9e4fed93a0a3d99bae49bf127cfddb5fed0cebeac6f1ee4b6ce39_prof);

        
        $__internal_f540e1ba7c5ab7e9b812dd346559cb7f5025a4c870c747f94d0e0676836cabb7->leave($__internal_f540e1ba7c5ab7e9b812dd346559cb7f5025a4c870c747f94d0e0676836cabb7_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle::index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'AppBundle::layout.html.twig' %}", "AppBundle::index.html.twig", "C:\\wamp64\\www\\gabycv\\src\\AppBundle/Resources/views/index.html.twig");
    }
}
